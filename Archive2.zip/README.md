# kretek
chodzisz kretem
